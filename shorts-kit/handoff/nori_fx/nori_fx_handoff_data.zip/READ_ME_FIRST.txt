nori(FX)ショート制作の引き継ぎデータ(軽量版)

入っているもの
- docs/    引き継ぎ書(HANDOFF_nori_fx.md と同じ内容)・アカウント・定期作業・未完了タスク・実績CSV・ファイル一覧
- repo/    制作キットの原本(PLAYBOOK.md・CONTRACT.md・CLAUDE.md・台本・投稿文・ブリーフ・検品記録・ツール・数値データ)
- images/  コンタクトシート・提案画像・絵コンテ
- source/  10/22 ドル円15分足の高画質スクリーンショット(hq1022)・のりラジオ1107 の文字起こし(src.srt)

入っていないもの(大きいので外した)
- フォント: しっぽり明朝(Shippori Mincho)・M PLUS Rounded 1c・Dela Gothic One。Google Fonts で無料で取れる。repo/fonts/ に置けばツールが動く
- 完成動画4本: ユーザーが受け取り済み(fx_usdjpy_box_v9_bgm.mp4 / fx_usdjpy_1022_v15_sfx.mp4 / fx_spread_1107_v8.mp4 / fx_tri_1107_v1.mp4)
- のりラジオ1107 の元動画: GigaFile https://105.gigafile.nu/1107-c168fa838c81b44240a99488905ad073d (期限切れならユーザーに再送を頼む)
- 同じ原本は GitHub tos104/- のブランチ claude/shorts-kit の shorts-kit/ にもある
